package com.example.tuningfeedback;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class SplashActivityLoading extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Handler handler = new Handler();
            handler.postDelayed(new Runnable()
            {
                public void run(){
                startActivity(new Intent(SplashActivityLoading.this,MainActivity.class));
                finish();
            }
            // 3000 milliseconds = 3 seconds
        } ,3000);


    }
}