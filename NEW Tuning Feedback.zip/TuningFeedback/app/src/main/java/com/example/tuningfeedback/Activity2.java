package com.example.tuningfeedback;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.os.Bundle;
import android.os.Vibrator;
public class Activity2 extends AppCompatActivity {
    ToggleButton mic;
    TextView mic_status;
    ImageButton Tuner;
    TextView tuneTxt;
    TextView noteText;
    MediaPlayer mp;
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        Tuner = findViewById(R.id.tuner);
        tuneTxt = findViewById(R.id.tuneText);
        mic = findViewById(R.id.muteButton2);
        mic_status = findViewById(R.id.micState2);
        noteText = findViewById(R.id.noteTxt);
        noteText.setText(" ");
        mic_status.setText("Mic off");
        tuneTxt.setText(" ");
        Tuner.setOnClickListener(new View.OnClickListener() {
            int counter = 0;
            @Override
            public void onClick(View view) {
                if ( mic_status.getText() == "Mic on"){
                    counter++;
                }
                else
                    return;
                if (counter==1 ){
                    Tuner.setImageResource(R.drawable.redup);
                    tuneTxt.setText("Too flat tune up");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("E");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==2){
                    Tuner.setImageResource(R.drawable.yellowdown);
                    tuneTxt.setText("Slightly sharp tune down");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("E");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==3){
                    Tuner.setImageResource(R.drawable.greenthumbs);
                    tuneTxt.setText("You're in tune");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("E");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION));
                    mp.start();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(400);
                }
                if (counter==4){
                    Tuner.setImageResource(R.drawable.yellowup);
                    tuneTxt.setText("Slightly flat tune up");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("A");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==5){
                    Tuner.setImageResource(R.drawable.reddown);
                    tuneTxt.setText("Too sharp tune down");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("A");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==6){
                    Tuner.setImageResource(R.drawable.yellowdown);
                    tuneTxt.setText("Slightly sharp tune down");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("A");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==7){
                    Tuner.setImageResource(R.drawable.greenthumbs);
                    tuneTxt.setText("You're in tune");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("A");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION));
                    mp.start();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(400);
                }
                if (counter==8){
                    Tuner.setImageResource(R.drawable.redup);
                    tuneTxt.setText("Too flat tune up");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("D");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==9){
                    Tuner.setImageResource(R.drawable.yellowup);
                    tuneTxt.setText("Slightly flat tune up");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("D");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }

                if (counter==10){
                    Tuner.setImageResource(R.drawable.greenthumbs);
                    tuneTxt.setText("You're in tune");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("D");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION));
                    mp.start();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(400);
                }
                if (counter==11){
                    Tuner.setImageResource(R.drawable.reddown);
                    tuneTxt.setText("Too sharp tune down");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("G");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==12){
                    Tuner.setImageResource(R.drawable.yellowdown);
                    tuneTxt.setText("Slightly sharp tune down");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("G");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }

                if (counter==13){
                    Tuner.setImageResource(R.drawable.greenthumbs);
                    tuneTxt.setText("You're in tune");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("G");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION));
                    mp.start();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(400);
                }
                if (counter==14){
                    Tuner.setImageResource(R.drawable.yellowup);
                    tuneTxt.setText("Slightly flat tune up");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("B");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }

                if (counter==15){
                    Tuner.setImageResource(R.drawable.greenthumbs);
                    tuneTxt.setText("You're in tune");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("B");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION));
                    mp.start();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(400);
                }
                if (counter==16){
                    Tuner.setImageResource(R.drawable.reddown);
                    tuneTxt.setText("Too sharp tune down");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("e");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==17){
                    Tuner.setImageResource(R.drawable.redup);
                    tuneTxt.setText("Too flat tune up");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("e");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==18){
                    Tuner.setImageResource(R.drawable.yellowdown);
                    tuneTxt.setText("Slightly sharp tune down");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("e");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }
                if (counter==19){
                    Tuner.setImageResource(R.drawable.yellowup);
                    tuneTxt.setText("Slightly flat tune up");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("e");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM));
                    mp.start();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    mp.stop();
                }

                if (counter==20){
                    Tuner.setImageResource(R.drawable.greenthumbs);
                    tuneTxt.setText("You're in tune");
                    tuneTxt.setScaleX(2);tuneTxt.setScaleY(2);
                    noteText.setText("e");
                    noteText.setScaleX(2);noteText.setScaleY(2);
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION));
                    mp.start();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(400);
                }
                if (counter>20){
                    counter =0;
                }







            }

        });
        mic.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(mic.isChecked()) {

                    mic_status.setText("Mic on");
                    Tuner.setImageResource(R.drawable.earlistening);
                }
                else {
                    Tuner.setImageResource(R.drawable.nosound);noteText.setText(" ");tuneTxt.setText(" ");
                    mic_status.setText("Mic off ");
                }
            }
        });
    }
}